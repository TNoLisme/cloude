# BE-COM-IMP-02 — Verification report

> **Dự án:** Digital Banking MVP
> **Task / phiên bản task:** [BE-COM-IMP-02](../tasks/BE-COM-IMP-02.md), v1.0 ngày 12/11/2026; source snapshot/hash E04
> **Ngày / người thực hiện:** 12/11/2026, UTC+07:00 — Codex theo yêu cầu của Phương
> **Trạng thái task:** Done — implementer verified
> **Kết luận verification:** Verified trong phạm vi error model, writer và mapper
> **Reviewer / sign-off:** Chưa review

## 1. Phạm vi và baseline

Triển khai 46 mã public, business exception, RFC 9457 Problem, factory/writer dùng được trong MVC/filter/security và exception mapping. Không tạo success envelope; không query bảng owner, ghi audit, thay transfer state hoặc retry transaction. Trace pipeline thật (03), body-limit/security/session thật (05), PostgreSQL lock/rollback/commit/concurrency (07) chưa được chứng minh bằng harness của task này.

- Revision gốc: `73f190e0a2f34b5f95cc295a90e5fe8a23a4479b`; working tree chưa commit. E04 có snapshot nguồn đầy đủ runtime/test/build và contract cần để chạy lại, cùng manifest SHA-256. Giữ nguyên các thay đổi IMP-01 và backlog/report/template đã có trước phiên; không dùng Git diff của toàn workspace làm diff riêng task 02.
- Môi trường: Linux 7.0.0-43-generic, OpenJDK 21.0.13.0.3, Gradle wrapper 8.14.3, Spring Boot 3.5.7. MockMvc slice dùng SecurityFilterChain riêng, Clock.fixed `2026-11-12T07:00:00Z` và ObjectMapper ISO như app. Regression nền dùng profile test và PostgreSQL 16.15 thật qua Testcontainers `postgres:16-alpine` (Docker 29.8.0 theo XML).
- Dependency IMP-01: dùng Clock UTC hiện tại; 20 AppPropertiesTest và toàn suite nền chạy lại đạt E03. Security production chưa gắn writer, test health vẫn giữ baseline 403 hiện tại; đây không phải bằng chứng đạt policy 401/session đích. Không sửa chain để mở rộng task 02 sang 05.
- Thứ tự nguồn: docs-common/01–11 → design → backend. Không phát hiện xung đột mới giữa 01–11 cần quyết định owner trong phạm vi task. Giữ retry/backoff 2 giây là đề xuất, không tự sign-off policy rate limit.

| Nguồn đã đọc / mục | Oracle và truy vết |
|---|---|
| [README gốc](../../../../README.md), [docs-common README](../../../../docs-common/README.md), [backend README](../../../README.md) | Cách tra cứu, ranh giới tài liệu và thứ tự ưu tiên |
| [07. API contracts](../../../../docs-common/07.%20API%20contracts.md) §3.2, §4.1–4.4, §7.2.4, §10 | 401 WWW-Authenticate, 46 public codes, required Problem/errors/extensions, retryable/Retry-After, schema challenge, direct success DTO; CT-API-004/009/010/013/015/016/017 chỉ phần formatter |
| [OpenAPI](../../../../openapi/digital-banking-v1.yaml) ErrorCode/Problem/ValidationProblem/Challenge/Reference/TransferFailureCode | Đối chiếu enum/required fields và các giá trị extension, không nâng YAML cao hơn ngữ nghĩa 07 |
| [design/02](../../../../docs-common/design/02.%20consistency-concurrency.md) §7.10, §11.5–11.6, Appendix C | SQLSTATE và rollback/retry do owner; audit context ưu tiên; không suy idempotency từ constraint hoặc SQL text |
| [09. Test plan](../../../../docs-common/09.%20Test%20plan.md) §2.2, §3, §7.7, §8, §10 | Trạng thái evidence, component/contract checks, giới hạn mock so với DB thật; lưu failed run/retest/revision |
| [common README](../README.md) §1.2–1.5, §2.4, §4, §7; [task index](../tasks/README.md) | Ownership, COM-HTTP-01/02/03 và COM-PII-03 ở mức thành phần; SQLSTATE chỉ mapping, chưa nghiệm thu toàn COM-DB-01..04; NFR-018/020/028, AC-030 theo traceability backend |

## 2. Thay đổi thực tế

| File/thành phần | Thay đổi và mục đích | AC được đáp ứng |
|---|---|---|
| [ErrorCode.java](../../../../../digitalbanking-backend/src/main/java/com/simulatedbank/banking/common/error/ErrorCode.java) | Public catalog, HTTP/retryable/type/title/default detail cố định | AC01/02/05 |
| [BankingBusinessException.java](../../../../../digitalbanking-backend/src/main/java/com/simulatedbank/banking/common/error/BankingBusinessException.java), [ProblemResponse.java](../../../../../digitalbanking-backend/src/main/java/com/simulatedbank/banking/common/error/ProblemResponse.java) | Owner-classified failure/cause; allowlist/flatten extensions, kiểm ngữ cảnh và challenge required, không override core | AC02/04/05 |
| [ProblemWriter.java](../../../../../digitalbanking-backend/src/main/java/com/simulatedbank/banking/common/error/ProblemWriter.java) | Clock, trace fallback, content type/401/retry headers; response factory cho MVC, servlet writer cho filter/security; bảo vệ committed response, log code/status/trace | AC02/03/05 |
| [GlobalExceptionHandler.java](../../../../../digitalbanking-backend/src/main/java/com/simulatedbank/banking/common/error/GlobalExceptionHandler.java), [DatabaseErrorMapper.java](../../../../../digitalbanking-backend/src/main/java/com/simulatedbank/banking/common/error/DatabaseErrorMapper.java) | Spring advice cho framework/validation/auth/security/DB/unexpected, owner classification trước SQL cause, không log raw cause | AC03/04/05 |
| [ErrorContractTest.java](../../../../../digitalbanking-backend/src/test/java/com/simulatedbank/banking/common/error/ErrorContractTest.java), [ErrorHttpTest.java](../../../../../digitalbanking-backend/src/test/java/com/simulatedbank/banking/common/error/ErrorHttpTest.java) | 18 test cases cuối; đầy đủ catalog, serialization/extensions, MockMvc/security/filter, DB table mapping và negative output checks | AC01–05 |
| [Backend README](../../../../../digitalbanking-backend/README.md), [common README](../README.md), [task](../tasks/BE-COM-IMP-02.md), [task index](../tasks/README.md), report/evidence này | Hướng dẫn sử dụng/trust boundary, current Java API, trạng thái implementer và bàn giao | G01/G02/G04 |

Sửa ngoài common chỉ ở backend README hướng dẫn consumer; không sửa module nghiệp vụ, migration, dependency build, cấu hình hay chain production. Common README v1.4 giữ phần IMP-01; nguồn docs-common/OpenAPI giữ nguyên.

## 3. Ma trận tiêu chí chấp nhận

| AC ID | Tiêu chí / kết quả kỳ vọng từ nguồn | Test hoặc cách kiểm tra | Kết quả thực tế | Evidence ID | Trạng thái |
|---|---|---|---|---|---|
| COM-G01 | Hành vi và test oracle truy được về nguồn chuẩn; khác biệt/đề xuất còn mở được ghi rõ, không tự đổi contract/policy | Đối chiếu nguồn §1; entireCatalogMatchesSemanticSourceAndOpenApi | 46 code/status/retryable khớp 07 và YAML; không sửa nguồn hoặc thêm alias/internal code | E03, E04 | Verified |
| COM-G02 | Diff đúng phạm vi task, giữ dependency và ownership của common; không thêm nghiệp vụ hoặc abstraction chưa có nhu cầu | Diff/scope review; ModuleBoundaryArchTest (4 rules) | 6 file production đều trong common/error; không import ngược, query/repository/transaction/retry/audit write; giữ nguyên thay đổi IMP-01 | E03, E04 | Verified |
| COM-G03 | Kiểm thử phù hợp cho thay đổi đã chạy và đạt; không dùng mock/H2 để chứng minh lock, constraint hay persistence PostgreSQL | Focused test và clean build; PostgreSQL regression | 47 pass, 0 fail/error/skip; exit 0. Mock SQLException chỉ chứng minh mapping; PostgreSQL regression chỉ chứng minh nền Flyway/JPA | E02, E03 | Verified |
| COM-G04 | Report đủ mọi AC, docs liên quan đồng bộ, giới hạn và việc bàn giao có đầu mối; evidence không lộ secret/PII | Report này, docs đồng bộ, snapshot/hash và kiểm tra link/evidence | Đủ 9 AC, artifact tồn tại, dữ liệu synthetic; password Spring sinh tự động trong XML đã redact; bàn giao rõ §6 | E04, E05 | Verified |
| COM-IMP-02-AC01 | Toàn bộ public code, HTTP status và retryable khớp catalog `07` §4.3; internal codes không trả client; không dùng alias từ nguồn cấp dưới | entireCatalogMatchesSemanticSourceAndOpenApi | Parse toàn bảng 07 §4.3.1–6; so khớp mọi mã/HTTP/retryable và enum YAML; reject internal codes/alias | E03 | Verified |
| COM-IMP-02-AC02 | Problem có đủ field bắt buộc, content type, detail an toàn, errors[] và extension đúng ngữ cảnh; extension không ghi đè core; success DTO không bị auto wrap | entireCatalogMatchesSemanticSourceAndOpenApi; validationAndContextualExtensionsAreFlattenedWithoutChangingCore; successIsNotWrapped | Required fields đúng YAML, timestamp ISO UTC; errors[].field/code/message; extensions flatten, chặn override/khác ngữ cảnh, STEP_UP cần challenge; không requestId hoặc success envelope | E03 | Verified |
| COM-IMP-02-AC03 | Validation, JSON sai, media/method/route sai và exception bất ngờ được map đúng; writer dùng được ngoài MVC; hỗ trợ 401/403, WWW-Authenticate và Retry-After theo contract | frameworkFailuresHaveTheContractFormat; mvcAuthenticationAuthorizationAndUnexpectedFailuresAreSafe; filterAndSecurityEntryPointsUseSharedWriter; servletWriterWorksWithoutMvcAndDoesNotRewriteCommittedResponse; constraintValidationNeverEchoesCustomMessagesAndReturnViolationsAreInternal | 400/404/405/415/500 đúng format; input validation 400, return-value 500; writer ngoài MVC, security harness 401/403, WWW-Authenticate; Retry-After cho 409/429/503. Harness body-limit chỉ kích writer, chưa enforcement thật | E03 | Verified |
| COM-IMP-02-AC04 | DB mapping phân biệt 55P03 in-progress có ngữ cảnh với lock timeout; unique idempotency do owner phân loại, invariant không thành lỗi client; lỗi audit đã xác định không bị generic mapper nuốt mất | databaseSqlStateMappingDoesNotInferBusinessRules (9 cases); ownerClassificationWinsOverSqlCause | 55P03 thô → 503; owner in-progress → 409; unique/check/invariant không bị biến thành business 409; owner conflict/role/audit được giữ kể cả wrap; resource/08xxx → 503; state lạ/thiếu → 500 | E03 | Verified |
| COM-IMP-02-AC05 | Response/log do error layer tạo không lộ SQL, schema/constraint, provider detail, rejected secret/PII hoặc stack trace chưa redaction | frameworkFailuresHaveTheContractFormat; mvcAuthenticationAuthorizationAndUnexpectedFailuresAreSafe; DB/security tests với CapturedOutput; constraintValidationNeverEchoesCustomMessagesAndReturnViolationsAreInternal | Synthetic password/OTP/email/account/SQL/schema/constraint/provider trong annotation/rejected value/cause không có ở body/log thực; error layer không log Throwable/stack/detail/path/extensions | E03, E04 | Verified |

## 4. Nhật ký kiểm chứng và evidence

Lệnh Gradle chạy tại `/home/phuong/workspace/cloude/digitalbanking-backend`; inspection/snapshot chạy tại workspace root. Thời gian UTC+07:00 ngày 12/11/2026; XML timestamp UTC cộng 7 giờ để đối chiếu.

| Evidence ID | Thời điểm / môi trường / revision | Working directory + lệnh hoặc bước thực chạy | Expected → actual; exit code, pass/fail/skip | Artifact tái kiểm tra được |
|---|---|---|---|---|
| E00 | Trước focused test, setup | backend: `./gradlew compileJava --console=plain`; root: `./gradlew test --tests '*common.error.*' --console=plain` | Lần compile sandbox exit 1 vì cache Gradle read-only; compile chạy lại với quyền cache exit 0. Lệnh test tại root exit 127 vì wrapper nằm trong backend; chưa chạy test | [Setup record](evidence/BE-COM-IMP-02/setup.txt) |
| E01 | 14:13:47–14:13:51, source trước sửa harness | backend: `./gradlew test --tests '*common.error.*' --console=plain` | Mong pass → 21 checks, 16 fail, 5 pass, 0 error/skip; exit 1. Fixture controller chưa đăng ký, mapper test dùng numeric timestamp; captured failed MockMvc print gây leak sentinel synthetic trong chính log test thất bại | [Initial log](evidence/BE-COM-IMP-02/initial/focused.log), [contract XML](evidence/BE-COM-IMP-02/initial/TEST-com.simulatedbank.banking.common.error.ErrorContractTest.xml), [HTTP XML](evidence/BE-COM-IMP-02/initial/TEST-com.simulatedbank.banking.common.error.ErrorHttpTest.xml) |
| E02 | Sau E01, trước bổ sung kiểm challenge/constraint | backend: `./gradlew test --tests '*common.error.*' --console=plain` | Explicit import fixture và cấu hình mapper ISO theo Boot → pass, exit 0. Lần này không phải source cuối; E03 kiểm source cuối | [Retest log](evidence/BE-COM-IMP-02/focused-retest.log) |
| E03 | Khoảng 14:16:02–14:16:21, final runtime/test source E04 | backend: `./gradlew clean build --console=plain` | Compile/package/test/check/JaCoCo đạt; 47 pass, 0 fail/error/skip, exit 0. Có PostgreSQL 16.15 thật cho regression migration | [Build log](evidence/BE-COM-IMP-02/build.log), [totals](evidence/BE-COM-IMP-02/test-summary.txt), [contract XML](evidence/BE-COM-IMP-02/TEST-com.simulatedbank.banking.common.error.ErrorContractTest.xml), [HTTP XML](evidence/BE-COM-IMP-02/TEST-com.simulatedbank.banking.common.error.ErrorHttpTest.xml), [ArchUnit](evidence/BE-COM-IMP-02/TEST-com.simulatedbank.banking.architecture.ModuleBoundaryArchTest.xml), [PostgreSQL](evidence/BE-COM-IMP-02/TEST-com.simulatedbank.banking.migration.PostgreSqlFlywayMigrationIntegrationTest.xml) |
| E04 | Sau E03, chỉ đồng bộ docs/evidence | root: `git diff --check`; `rg` ownership; hash/snapshot script | Diff exit 0; ownership search exit 1 = không match business imports/transaction/repository/job. Source snapshot tái tạo được runtime và contract đọc trong test; không lấy `.env` hoặc dump env | [Inspection](evidence/BE-COM-IMP-02/inspection.txt), [manifest](evidence/BE-COM-IMP-02/source.sha256), [snapshot](evidence/BE-COM-IMP-02/source-snapshot.tar.gz) |
| E05 | Khi hoàn tất report | root: chạy [verify-evidence.py](evidence/BE-COM-IMP-02/verify-evidence.py) để kiểm manifest, link, AC, XML totals, redaction và archive | Lần đầu thiếu integrity.txt tự sinh; đã tạo artifact và chạy lại tất cả đạt, exit 0; runtime/test sau E03 không đổi | [Integrity](evidence/BE-COM-IMP-02/integrity.txt) |

Test mapping và giới hạn:

- **COM-HTTP-02 / AC01–02:** `entireCatalogMatchesSemanticSourceAndOpenApi` đọc trực tiếp bảng `07` và YAML, so toàn bộ 46 code/status/retryable; serialize từng code; so required fields. `validationAndContextualExtensionsAreFlattenedWithoutChangingCore` kiểm errors/step-up/audit/lock, core override/internal field/invalid context/reference/status/failure/challenge; không dùng vài code mẫu thay full catalog.
- **COM-HTTP-01 / AC03:** `frameworkFailuresHaveTheContractFormat` chạy HTTP validation, malformed JSON, media/method/route, missing/type-invalid query, native method input và return validation. `constraintValidationNeverEchoesCustomMessagesAndReturnViolationsAreInternal` chạy validator thật và gọi advice cho ConstraintViolationException input/return. `successIsNotWrapped` giữ DTO.
- **COM-HTTP-03, CT-API-004/015/016, chỉ formatter:** MVC auth exceptions và SecurityFilterChain harness thật chạy entrypoint/denied handler với writer. Không chứng minh session expiry/CSRF/RBAC/ownership toàn hệ thống.
- **COM-DB-01..04, chỉ mapping / AC04:** SQLException synthetic cho 55P03/40P01/40001/57014/08006/08007/23505/23514/XX000; owner BankingBusinessException được bọc trong DataAccessException để kiểm in-progress/conflict/role/audit ưu tiên; missing-state/resource failures được kiểm riêng. Không tạo lock, constraint hoặc transaction thật trong test mapping, không dùng H2 để chứng minh persistence.
- **COM-PII-03 / AC05:** `CapturedOutput` và response body thực được kiểm không có sentinel password/OTP/email/account/SQL/schema/constraint/provider hoặc stack trace test. Annotation message/rejected body và nested SQL/security/unexpected cause đều chứa fixture synthetic. Log error layer chỉ code/status/correlationId; detail và extension do owner cung cấp là input công khai đã an toàn, không phải đầu vào raw cần tự động che.
- Regression PostgreSQL hiện có chỉ chứng minh Flyway/JPA nền vẫn chạy; không được dùng thay DB behavior integration của IMP-07. Không có test bắt buộc của task 02 bị skip/blocked. Không chạy Cloud/TLS/proxy, real body limit, identity session, concurrency hoặc money path.

XML evidence sao từ Gradle, chỉ redact dòng password Spring sinh tự động; không đổi testcase/assertion/count/timestamp. Initial failed HTTP artifact có sentinel synthetic do MockMvc in request sau assertion fail; không có credential/PII thật. Sau sửa harness E02/E03 negative output checks đạt.

## 5. Gap, lỗi và quyết định còn mở

| ID | AC ảnh hưởng | Gap/lỗi và tác động | Trạng thái | Đầu mối / điều kiện tiếp tục | Quyết định hoặc evidence liên quan |
|---|---|---|---|---|---|
| HARNESS-01 | G03/AC02/03/05 | Fixture chưa được import, ObjectMapper test khác ISO config app; fail cascade/output capture có request dump synthetic | Fixed và retested | Codex; explicit fixture import + mapper config; E03 pass | E01–E03 |
| TRACE-WIRING | Ngoài acceptance độc lập task 02; cần cho toàn pipeline | Writer nhận request attribute correlationId hoặc UUID fallback, chưa filter validate/cleanup/mọi response | Handoff | IMP-03 / Phương; dùng chung attribute, kiểm all-dispatch headers/context | common §2.4, E03 harness |
| SECURITY-WIRING | Phần wiring/enforcement task 05 | Production chain còn baseline, chưa gắn entrypoint/denied writer; body-limit test chỉ gọi writer, chưa đếm byte body | Handoff | IMP-05 / Phương + Đạt identity; CSRF/session/auth thật, limiter/proxy enforcement | Task 02 AC03 quy định body-limit ở 05 |
| DATABASE-INTEGRATION | Phần PostgreSQL task 07 | Mapping pass không chứng minh rollback, audit atomicity, lock timeout/NOWAIT hoặc commit uncertain | Handoff | IMP-07 / Phương với transfer/limit Vũ, audit Thịnh; TX/connection độc lập trên PG16 | Task 02 AC04 quy định DB thật ở 07 |
| OWNER-PUBLIC-DATA | Không chặn formatter AC; contract của caller | Owner phải đưa safeDetail/extension public-safe, mask destination, đúng FIDO options; không truyền raw exception/entity. Common không đoán nội dung nghiệp vụ | Handoff | Identity/transfer/audit owners, review caller trước tích hợp | 07 §4.2/§7.2.4; common §2.4 |
| RETRY-POLICY | Không chặn header contract AC03 | Retry-After 2s là default đề xuất trong khoảng 1–5s; chưa policy rate limiter được sign-off; không cho phép retry mọi POST | Đề xuất tại nguồn | IMP-05/07 và owner policy; đồng bộ với limiter thực trước release | 07 §4.4; design/02 §7.10 |

Không có gap ảnh hưởng tiêu chí task 02 còn chưa đạt. Các phần bàn giao được giữ đúng ranh giới đã ghi trong task, không hạ hoặc chuyển AC bắt buộc thành N/A/Deferred để đóng task.

## 6. Kết luận và bàn giao

- Tổng **9 AC**: **9 Verified**, 0 chưa đạt/chưa kiểm chứng trong phạm vi BE-COM-IMP-02; **47 tests pass, 0 fail/error/skip** ở clean build E03.
- Kết luận implementer: đạt phạm vi error model/writer/mapper; đề nghị **Done**, chờ review. Không đồng nghĩa common, security, DB transaction hoặc toàn hệ thống đã nghiệm thu.
- **IMP-03 / Phương:** đưa validated correlationId vào request attribute trước error/security, hoàn thiện context/MDC/header/cleanup cho success/lỗi/redispatch; fallback writer chỉ hỗ trợ độc lập.
- **IMP-05 / Phương + Đạt:** inject ProblemWriter trong production AuthenticationEntryPoint/AccessDeniedHandler và filter limit; kiểm session/CSRF/401/403/body limit thật. Không suy khả năng này từ harness fixture.
- **IMP-07 / Phương + Vũ/Thịnh:** kiểm NOWAIT/lock_timeout, deadlock/serialization/cancel/connection loss/unique/check và audit rollback trên PG16; owner phân loại in-progress/idempotency/audit trước advice, retry nằm ngoài transaction và giữ cùng key.
- **IMP-06 / Phương:** nối log/metrics nền, không log raw cause/detail/extensions, không đếm lặp owner retry hoặc thay audit bằng technical log.
- **Review/sign-off thực tế:** Chưa review. Backend Lead/QA/Security cần review diff/evidence và các consumer; không tự nhận phê duyệt thay reviewer.
