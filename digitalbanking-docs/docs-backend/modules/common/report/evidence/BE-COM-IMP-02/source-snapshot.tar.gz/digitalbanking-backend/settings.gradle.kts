rootProject.name = "digitalbanking-backend"
