#!/bin/sh
set -eu
export JAVA_HOME="$(/usr/libexec/java_home -v 21)"
export DOCKER_HOST="$(docker context inspect desktop-linux --format '{{.Endpoints.docker.Host}}')"
export TESTCONTAINERS_DOCKER_SOCKET_OVERRIDE=/var/run/docker.sock
./gradlew test --tests '*TransferT2PostgreSqlIntegrationTest' \
  --tests '*TransferT0T1PostgreSqlIntegrationTest' --tests '*TransferSettlementCandidate*Test' \
  --tests '*TransferRecoveryCandidatePostgresTest' --tests '*TransferBoundaryTest' \
  --tests '*ModuleBoundaryArchTest' --tests '*AuditBoundaryArchTest' \
  --tests '*AuditModulePostgreSqlIntegrationTest' --tests '*AuditSnapshotContractTest' \
  --tests '*AuditEventValidatorTest' --tests '*AuditWriterIT' --tests '*SafeJsonLogEncoderTest' \
  --tests '*FraudRuleEvaluatorTest' --tests '*FraudFlagIT' --tests '*FraudJpaRepositoryIT' \
  --tests '*NotificationTransactionalOutboxIT' --tests '*NotificationJpaRepositoryIT' \
  --tests '*FraudV21MigrationPostgreSqlIntegrationTest' --tests '*TransferLimitV20MigrationPostgreSqlIntegrationTest' \
  --tests '*PostgreSqlFreshMigrationIntegrationTest' --tests '*AccountV8MigrationPostgreSqlIntegrationTest' \
  --tests '*ApprovalPrivilegesV18MigrationPostgreSqlIntegrationTest' \
  --tests '*ApprovalRequestV6MigrationPostgreSqlIntegrationTest' \
  --tests '*AdminIdempotencyV7MigrationPostgreSqlIntegrationTest' \
  --tests '*AccountBalancePostgreSqlIntegrationTest' --tests '*AccountLockPostgreSqlIntegrationTest' \
  --tests '*AccountConcurrencyPostgreSqlIntegrationTest' --tests '*AccountPersistencePostgreSqlIntegrationTest' \
  --tests '*Customer*PostgreSqlIntegrationTest' --tests '*LimitConfigMutationPostgreSqlIntegrationTest' \
  --tests '*SessionCustomerAccountReadPostgreSqlIntegrationTest' \
  --tests '*TransferLimitPostgreSqlIntegrationTest' --tests '*LimitPersistenceIT' --tests '*LedgerPosting*Test' --console=plain
